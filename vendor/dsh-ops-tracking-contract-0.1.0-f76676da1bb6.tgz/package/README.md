# @dsh-ops/tracking-contract

产品 Host 与独立官网共用的唯一运营事件契约源码。只依赖 `zod@4.4.3`，不导入 DSH、Cordis、文件系统或网络，不是 Cordis 插件。采集与上传生命周期仍归 `@dsh-ops/tracking`；旧 `@dsh-ops/tracking/contracts` re-export 本包以兼容产品调用。

目录版本 4，事件、批次 `schemaVersion` 与 `eventVersion` 保持 1。旧版工号事件与匿名事件仍可读取，不回填历史资料。

`employee` 的身份键为 `source: 'welink'` + `employeeId`（小写工号）。可选展示资料为 `chineseName`（128 字符）、`departmentName`（1024）、`deptL1Name` / `deptName`（各 256），以及 `profileUpdatedAt`（ISO UTC 时间）。文字去首尾空白、不能为空或含控制字符；未知字段拒收，不接受邮箱、凭据与联系人原始 JSON。姓名与部门不参与用户去重或授权。

```sh
pnpm --filter @dsh-ops/tracking-contract build
pnpm --filter @dsh-ops/tracking-contract typecheck
pnpm --filter @dsh-ops/tracking-contract test
```

官网从此目录执行 `pnpm pack --pack-destination <官网 vendor 目录>`，以内容哈希命名新制品，并更新来源清单、依赖及锁文件。不得重新打包包含 Host 私有 workspace 依赖的 `logger-tracking` 作为官网协议。先部署并重启支持新契约的官网，再发布客户端；旧官网的严格校验会拒收新增资料字段。详见 [ADR 0019](../../../docs/adr/0019-operation-tracking-and-analytics.md)。
